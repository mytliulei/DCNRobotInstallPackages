"""This module implements exceptions used internally by daemonocle."""


class DaemonError(Exception):
    """An exception class that daemonocle can raise for errors."""
    pass
